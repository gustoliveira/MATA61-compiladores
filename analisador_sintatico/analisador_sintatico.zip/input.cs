class Program {
    static void Main() {
        static int x;
        x = 10;
    }
}

