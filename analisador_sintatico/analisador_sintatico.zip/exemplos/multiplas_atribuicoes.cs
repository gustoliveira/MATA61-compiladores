class Program {
    static int number;
    static string message;
    
    static void Main() {
        number = 42;
        message = "Hello";
        
        if(number == 42) {
            return number;
        }
    }
}

