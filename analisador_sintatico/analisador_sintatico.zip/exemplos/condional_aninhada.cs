class Program {
    static void Main() {
        value = 15;
        
        if(value < 10) {
            return 1;
        } else {
            if(value < 20) {
                return 2;
            } else {
                return 3;
            }
        }
    }
}

