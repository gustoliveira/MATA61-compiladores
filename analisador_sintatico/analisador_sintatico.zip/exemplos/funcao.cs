class Program {
    static void Calculate() {
        result = 100;
        return result;
    }

    static int Sum(int a, int b) {
        result = a + b;
        return result;
    }

    static Sub(int a, int b) {
        result = a - b;
        return result;
    }
    
    static void Main() {
        x = Sum(5, 3);
        x = Sub(5, 3);
        Calculate();
        return x;
    }
}
