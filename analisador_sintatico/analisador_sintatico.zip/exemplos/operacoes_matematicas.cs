class Program {
    static void Main() {
        a = 10;
        b = 5;
        
        sum = a + b;
        diff = a - b;
        mult = a * b;
        div = a / b;
        
        return mult;
    }
}

