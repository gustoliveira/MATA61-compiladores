class Program {
    static void Main() {
        static int x;
        x = 1;

        static int y;
        y = 1.0;

        static int z;
        z = 1.25;
    }
}
