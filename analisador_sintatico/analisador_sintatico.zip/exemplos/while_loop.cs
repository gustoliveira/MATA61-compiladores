class Program {
    static int x;
    
    static void Main() {
        x = 10;
        
        while (x < 20) {
            x = x + 2;
        }

        return x;
    }
}
